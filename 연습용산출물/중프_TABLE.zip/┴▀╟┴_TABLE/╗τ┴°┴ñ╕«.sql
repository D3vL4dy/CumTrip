select a.main_cate, b.mid_name, c.photo_path
		from main a, middle b,photo c 
		where a.main_code = b.main_code
		and b.mid_no = c.mid_no
		and b.mid_location like '����'||'%'
		and b.mid_no like 'F'||'%'
		and rownum <=9;
        
select photo_path from photo
		where mid_no in (select mid_no from middle where mid_location like
		'����������'||'%' and mid_no like 'F'||'%' );
        
        
select a.mid_no, a.mid_name, b.photo_path
  from middle a, photo b
 where a.mid_no = b.mid_no
   and a.mid_no like 'F%'
   and b.photo_path like '�ٿ�ε�%'
 order by 2;

        --tourList
		select a.main_cate, b.mid_name, c.photo_path
		from main a, middle b,photo c 
		where a.main_code = b.main_code
		and b.mid_no = c.mid_no
		and b.mid_no like 'T'||'%'
		and rownum <=9;
        
        --���帶ũ3, �ڹ���4, �ڿ�����2
        select * from(select a.main_cate, b.mid_name, c.photo_path, rownum as rnum
		from main a, middle b,photo c 
		where a.main_code = b.main_code
		and b.mid_no = c.mid_no
		and b.mid_no like 'T'||'%'
        and a.main_cate = '���帶ũ')
        where rnum >= 0  
        and rnum <= 9
        order by 1;
        --���帶ũ4, �ڹ���3, ����1, �ڿ�����1
        select * from(select a.main_cate, b.mid_name, c.photo_path, rownum as rnum
		from main a, middle b,photo c 
		where a.main_code = b.main_code
		and b.mid_no = c.mid_no
		and b.mid_no like 'T'||'%'
        and a.main_cate <> '���帶ũ'
        and a.main_cate <> '�ڹ���'
        and a.main_cate <> '����'
        and a.main_cate <> '����')
        where rnum >= 0  
        and rnum <= 9
        order by 1;
        --���帶ũ2, ����1, ����2, �ڿ�����3, ����1
        select * from(select a.main_cate, b.mid_name, c.photo_path, rownum as rnum
		from main a, middle b,photo c 
		where a.main_code = b.main_code
		and b.mid_no = c.mid_no
		and b.mid_no like 'T'||'%')
        where rnum >= 19  
        and rnum <= 27
        order by 1;
        
        
