insert into m_review (mre_no, mre_title, mre_content, mre_date, mre_point, mre_imgpath, mem_email, mid_no)
	  values('MR000'||mre_seq.nextval, #mre_title#, #mre_content#, sysdate, #mre_point#, #mre_imgpath#, #mem_email#, #mid_no#  )
      
      update m_review set mre_title = '����'
      where mre_no = 'MR00011'
      
      
     update m_review set mre_title = #mre_title#, mre_content = #mre_content#, mre_date = sysdate, mre_point = #mre_point#, mre_imgpath = #mre_imgpath# 
      where mre_no = #mre_no#
      
      update m_review 
      	 set mre_title = '', mre_content = '', mre_date = '', mre_imgpath = '' 
       where mre_no = 'MR00011'
      
      COMMIT
      
      delete from m_review where mre_no = 'MR00011';
      
      
      select a.mre_no as mre_no , a.mre_title as mre_title, a.mre_content as mre_content ,
		a.mre_date as mre_date, a.mre_point as mre_point ,
		 a.mre_imgpath as mre_imgpath, a.mem_email as mem_email, a.mid_no as mid_no, b.mem_photo as mem_photo
		from m_review a, member b 
		where a.mem_email = b.mem_email
		and a.mid_no = 'T00052';